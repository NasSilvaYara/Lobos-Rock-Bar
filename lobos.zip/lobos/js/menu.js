    document.addEventListener("DOMContentLoaded", () => {
    const menuToggle = document.querySelector('.menu-toggle');
    const navbar = document.querySelector('.navbar');
    const iconOpen = document.querySelector('.icon-abrir');
    const iconClose = document.querySelector('.icon-fechar');

    menuToggle.addEventListener('click', () => {
        navbar.classList.toggle('active');
        
        const menuAtivo = navbar.classList.contains('active');
        iconOpen.style.display = menuAtivo ? 'none' : 'block';
        iconClose.style.display = menuAtivo ? 'block' : 'none';
    });
});

  
  
  
  document.addEventListener("DOMContentLoaded", () => {
            // ----------------------------------------------------
            // INICIALIZAÇÃO
            // ----------------------------------------------------
            const carousel = document.getElementById("mainCarousel");
            const slidesContainer = document.querySelector(".Carrosel1");
            const slides = slidesContainer ? Array.from(slidesContainer.querySelectorAll(".slide")) : [];
            const btnProximo = document.querySelector(".proximo");
            const btnAnterior = document.querySelector(".anterior");
            const indicatorsContainer = document.getElementById("carouselIndicators");

            // Verifica se a estrutura essencial existe
            if (!slides.length || !carousel || !indicatorsContainer) {
                console.error("Carrossel não pode ser inicializado. Verifique se as classes .Carrosel, .Carrosel1, .slide e os IDs #mainCarousel, #carouselIndicators existem no HTML.");
                return;
            }

            const totalSlides = slides.length;
            let currentIndex = 0; // O índice central
            
            // Distância horizontal (em pixels) para slides laterais.
            // AUMENTADO para 300px para acomodar slides maiores
            const spacing = 300; 
            
            // As classes de perspectiva que o CSS usa
            const perspectiveClasses = ['active-center', 'active-right-1', 'active-right-2', 'active-right-3', 'active-left-1', 'active-left-2', 'active-left-3'];


            // ----------------------------------------------------
            // CRIAÇÃO DOS INDICADORES (Bolinhas)
            // ----------------------------------------------------
            slides.forEach((_, i) => {
                const bolinha = document.createElement("span");
                bolinha.classList.add("bolinha-item");
                if (i === 0) bolinha.classList.add("ativo");
                bolinha.addEventListener("click", () => moveTo(i));
                indicatorsContainer.appendChild(bolinha);
            });
            
            const indicators = indicatorsContainer.querySelectorAll(".bolinha-item");

            /**
             * Calcula o índice relativo (distância do centro)
             * e aplica as classes e transformações CSS/JS.
             * @param {number} centerIndex - O índice do slide atual (o que deve estar no centro).
             */
            function updateSlidePositions(centerIndex) {
                slides.forEach((slide, i) => {
                    slide.classList.remove(...perspectiveClasses);
                    slide.style.transform = '';
                    
                    // Calcula a diferença do centro
                    let relativeIndex = i - centerIndex;

                    // Lidar com o wrap-around para fazer o loop (índice relativo entre -totalSlides/2 e +totalSlides/2)
                    if (relativeIndex > totalSlides / 2) {
                        relativeIndex -= totalSlides;
                    } else if (relativeIndex < -totalSlides / 2) {
                        relativeIndex += totalSlides;
                    }

                    // O slide central
                    if (relativeIndex === 0) {
                        slide.classList.add('active-center');
                        slide.style.transform = 'translateX(0) scale(1.0)';
                        slide.style.zIndex = 5;
                        slide.style.opacity = 1;
                        return;
                    }
                    
                    // Slides à direita (positive relativeIndex)
                    if (relativeIndex > 0 && relativeIndex <= 3) {
                        slide.classList.add(`active-right-${relativeIndex}`);
                        slide.style.transform = `translateX(${relativeIndex * spacing}px) scale(${1.0 - relativeIndex * 0.15})`; // Spacing e Scale
                        slide.style.zIndex = 5 - relativeIndex;
                        slide.style.opacity = 1 - relativeIndex * 0.25;
                        return;
                    }

                    // Slides à esquerda (negative relativeIndex)
                    if (relativeIndex < 0 && relativeIndex >= -3) {
                        const absIndex = Math.abs(relativeIndex);
                        slide.classList.add(`active-left-${absIndex}`);
                        slide.style.transform = `translateX(${relativeIndex * spacing}px) scale(${1.0 - absIndex * 0.15})`; // Spacing e Scale
                        slide.style.zIndex = 5 - absIndex;
                        slide.style.opacity = 1 - absIndex * 0.25;
                        return;
                    }

                    // Slides muito distantes
                    slide.style.transform = 'translateX(0) scale(0.5)';
                    slide.style.zIndex = 0;
                    slide.style.opacity = 0;
                });
                
                // Atualizar indicadores (bolinhas)
                indicators.forEach((indicator, i) => {
                    indicator.classList.toggle("ativo", i === centerIndex);
                });
            }

            /**
             * Move o carrossel para um novo índice.
             * @param {number} newIndex - O índice do slide para mover.
             */
            function moveTo(newIndex) {
                currentIndex = (newIndex % totalSlides + totalSlides) % totalSlides;
                updateSlidePositions(currentIndex);
            }

            // ----------------------------------------------------
            // EVENT LISTENERS
            // ----------------------------------------------------
            if (btnProximo) {
                btnProximo.addEventListener("click", () => moveTo(currentIndex + 1));
            }
            if (btnAnterior) {
                btnAnterior.addEventListener("click", () => moveTo(currentIndex - 1));
            }

            // Garante que clicar no slide lateral o traga para o centro
            slides.forEach(slide => {
                slide.addEventListener('click', (e) => {
                    const index = parseInt(slide.dataset.index, 10);
                    if (index !== currentIndex) {
                        moveTo(index);
                    }
                });
            });

            // ----------------------------------------------------
            // INICIALIZAÇÃO
            // ----------------------------------------------------
            
            // Mostra o slide inicial e aplica as posições
            updateSlidePositions(currentIndex);

            // Autoplay (5 segundos)
             setInterval(() => moveTo(currentIndex + 1), 5000); 
        });